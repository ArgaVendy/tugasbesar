

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="card w-50">
            <div class="card-header">
                <h4>Struk Transaction</h4>
            </div>
            <div class="card-body">
                <h6>Id Transaksi <?php echo e($data->code_transaksi); ?></h6>
                <h6><?php echo e($data->nama_pembeli); ?></h6>
                
            </div>

            
        </div>
    </div>

    <script type="text/javascript">
        // For example trigger on button clicked, or any time you need
        var payButton = document.getElementById('pay-button');
        payButton.addEventListener('click', function() {
            // Trigger snap popup. @TODO: Replace TRANSACTION_TOKEN_HERE with your transaction token
            window.snap.pay(, {
                onSuccess: function(result) {
                    /* You may add your own implementation here */
                    alert("payment success!");
                    console.log(result);
                },
                onPending: function(result) {
                    /* You may add your own implementation here */
                    alert("wating your payment!");
                    console.log(result);
                },
                onError: function(result) {
                    /* You may add your own implementation here */
                    alert("payment failed!");
                    console.log(result);
                },
                onClose: function() {
                    /* You may add your own implementation here */
                    alert('you closed the popup without finishing the payment');
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\tubes_laravel_motor\resources\views/pelanggan/layout/page/detailTransaksi.blade.php ENDPATH**/ ?>