

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-row gap-2 mt-4">
        
        <div class="d-flex flex-wrap gap-4 mb-5" id="filterResult">
            <?php if($data->isEmpty()): ?>
                <h1>Belum ada product ...!</h1>
            <?php else: ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="width:200px;">
                        <div class="card-header m-auto">
                            <img src="<?php echo e(asset('storage/product/' . $p->foto)); ?>" alt="motor"
                                style="width: 100%;height:130px; object-fit: cover; padding:0;">
                        </div>
                        <div class="card-body">
                            <p class="m-0 text-justify" style="font-size: 14px;"> <?php echo e($p->nama_produk); ?> </p>
                            <p class="m-0"><i class="fa-regular fa-star"></i> 5+</p>
                        </div>
                        <div class="card-footer d-flex flex-row justify-content-between align-items-center">
                            <p class="m-0" style="font-size: 14px; font-weight:600;"><span>IDR
                                </span><?php echo e(number_format($p->harga)); ?></p>
                                <form action="<?php echo e(route('addTocart')); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name="idProduct" value="<?php echo e($p->id); ?>">
                                  <button type="submit" class="btn btn-outline-primary" style="font-size:24px">
                                      <i class="fa-solid fa-cart-plus"></i>
                                  </button>
                                </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="pagination d-flex flex-row justify-content-between" style="color: white">
        <div class="showData">
            Data ditampilkan <?php echo e($data->count()); ?> dari <?php echo e($data->total()); ?>

        </div>
        <div>
            <?php echo e($data->links()); ?>

        </div>
    </div>
    <?php endif; ?>

    <script>
        $(document).ready(function() {
            $('.kategori').change(function(e) {
                e.preventDefault();
                var value = $(this).val();
                var split = value.split(' ');
                var kategori = split[0];
                var tipe = split[1];
                // alert(type);
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('shop')); ?>",
                    data: {
                        kategori: kategori,
                        tipe: tipe,
                    },
                    success: function(response) {
                        console.log(response);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\tubes_laravel_motor\resources\views/pelanggan//layout/page/shop.blade.php ENDPATH**/ ?>